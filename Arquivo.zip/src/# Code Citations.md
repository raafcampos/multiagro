# Code Citations

## License: unknown
https://github.com/caiquemiranda/webapps-models/tree/f64fdacb774c1aa7c4e3e922bc1e23e16e46c51b/finance-app-py/index.html

```
index.html -->
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1
```


## License: unknown
https://github.com/LucRevoltz207/Head-Space/tree/9c0610705e48308f90f2a28edad212a4ee789a6c/Projeto%20HeadSpace/Topicos/testes/index.html

```
->
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
```

